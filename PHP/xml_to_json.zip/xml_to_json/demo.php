<?php


?>
<form action="http://dreamscoder.com/examples/xml_to_json/conversion.php" method="post" id="form" enctype="multipart/form-data">

<h3>Upload your XML file here </h3>

<p> Add XML File</p>
<input id="uploadBtn" name="xml" type="file" class="upload" />
<br>

<input type="submit" value="submit" name="submit">

</form>
